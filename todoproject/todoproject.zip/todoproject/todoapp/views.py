from django.shortcuts import render, redirect

from todoapp.forms import Todoform
from todoapp.models import Task


# Create your views here.
def addtask(request):
    task = Task.objects.all()
    if request.method == 'POST':
        name=request.POST.get('name','')
        priority=request.POST.get('priority','')
        date=request.POST.get('date','')
        task1=Task(name=name,priority=priority,date=date)
        task1.save()
    return render(request,'home.html',{'task':task})

# def details(request):
#
#     return render(request,'detail.html',)

def delete(request,taskid):
    taskids=Task.objects.get(id=taskid)
    if request.method == 'POST':
        taskids.delete()
        return redirect('/')
    return render(request,'delete.html')

def update(request,taskid):
    taskidss=Task.objects.get(id=taskid)
    form=Todoform(request.POST or None,instance=taskidss)
    if form.is_valid():
        form.save()
        return redirect('/')
    return render(request,'edit.html',{'taskid':taskidss,'forms':form})
