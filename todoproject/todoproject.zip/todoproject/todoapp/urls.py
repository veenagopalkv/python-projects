from django.urls import path
from . import views

app_name = 'todoapp'
urlpatterns = [
    path('',views.addtask,name='addtask'),
    path('delete/<int:taskid>/',views.delete,name='delete'),
    path('edit/<int:taskid>/',views.update,name='update')
]